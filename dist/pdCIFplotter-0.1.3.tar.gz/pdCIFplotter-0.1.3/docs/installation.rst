============
Installation
============

At the command line::

    pip install pdCIFplotter

If you would like the current development version from GitHub::

    pip install git+https://github.com/rowlesmr/pdCIFplotter
