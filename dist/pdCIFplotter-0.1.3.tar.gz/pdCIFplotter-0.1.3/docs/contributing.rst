.. include:: ../CONTRIBUTING.rst
