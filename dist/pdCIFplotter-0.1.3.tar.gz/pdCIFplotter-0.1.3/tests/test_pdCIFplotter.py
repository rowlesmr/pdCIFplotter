
from pdCIFplotter import main


def test_main():
    pass
